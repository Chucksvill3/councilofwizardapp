package com.example.myapplication.controller;// AirshipActivity.java

import android.content.res.AssetManager;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


import com.example.myapplication.R;
import com.example.myapplication.model.Airship;
import com.example.myapplication.model.Fleet;
import com.example.myapplication.model.Wizard;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class AirshipActivity extends AppCompatActivity {
    private Fleet fleet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_airship);

        String registry = getIntent().getStringExtra("registry");
        AssetManager assetManager = getAssets();

        try {
            fleet = new Fleet("Council Fleet");
            fleet.loadAirships(assetManager);

            Airship airship = fleet.getAirshipByRegistry(registry);
            TextView airshipName = findViewById(R.id.airshipName);
            airshipName.setText(airship.getName() + " (" + airship.getRegistry() + ")");

            loadWizards(assetManager, registry);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadWizards(AssetManager assetManager, String registry) throws IOException {
        InputStream inputStream = assetManager.open("wizards.csv");
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        String line;
        LinearLayout wizardList = findViewById(R.id.wizardListLayout);

        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length >= 5 && parts[4].equals(registry)) {
                Wizard wizard = new Wizard(parts[0], parts[1], parts[2], parts[3], parts[4]);
                TextView wizardInfo = new TextView(this);
                wizardInfo.setText(wizard.toString());
                wizardList.addView(wizardInfo);

                ImageView wizardImage = new ImageView(this);
                int imageRes = getResources().getIdentifier(parts[0].toLowerCase(), "drawable", getPackageName());
                wizardImage.setImageResource(imageRes);
                wizardList.addView(wizardImage);
            }
        }
        reader.close();
    }
}
